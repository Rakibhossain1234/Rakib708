# Login
INSTALLATION and use

1. `git clone https://github.com/TechnicalDangwal/Login.git`

2. `cd Login`

3. `python login.py`

`Now you want to set your username and password`


for more information visit to my Youtube Channel Technical Dangwal
